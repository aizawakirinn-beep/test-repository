# ローカルでの起動コマンド
```bash
$ docker build -t my-html-image .
docker run -d -p 8080:80 my-html-image
```